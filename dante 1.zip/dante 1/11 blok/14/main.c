#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX_SIZE 220


int validate(const char* number) {
    if (number == NULL) return -1;


    if (*number == '\0') return 1;


    const char* ptr = number;

    if (*ptr == '0') {
        ptr++;
        if (*ptr != '\0') return 0;
        return 1;
    }

    while (*ptr) {
        if (*ptr < '0' || *ptr > ('0' + (2*2*2) + 1)) return 0;
        ptr++;
    }

    return 1;
}



int add(const char* number1, const char* number2, char* result, int size) {
    if (number1 == NULL || number2 == NULL || result == NULL || size <= 0) {
        return 1;
    }

    if (*number1 == '-' || *number2 == '-') {
        return 1;
    }

    for (const char *ptr = number1; *ptr != '\0'; ++ptr) {
        if (!isdigit(*ptr)) return 1;
    }
    for (const char *ptr = number2; *ptr != '\0'; ++ptr) {
        if (!isdigit(*ptr)) return 1;
    }

    const char* ptr1 = number1 + strlen(number1) - 1;
    const char* ptr2 = number2 + strlen(number2) - 1;
    char* ptr = result + size - 1;

    int c = 0;

    *ptr = '\0';
    ptr--;

    while (ptr1 >= number1 || ptr2 >= number2 || c > 0) {
        int sum = c;

        if (ptr1 >= number1) {
            sum += *ptr1 - '0';
            ptr1--;
        }

        if (ptr2 >= number2) {
            sum += *ptr2 - '0';
            ptr2--;
        }

        if (ptr < result) return 2;
        *ptr = (sum % 10) + '0';
        c = sum / 10;
        ptr--;
    }

    ptr++;
    if (result + size - ptr - 1 >= size) {
        return 2;
    }
    memmove(result, ptr, result + size - ptr);

    return 0;
}

int main() {
    char num1[MAX_SIZE], num2[MAX_SIZE], res[MAX_SIZE];

    printf("Podaj pierwsza liczbe: ");
    int s1 = scanf("%200s", num1);
    int c;
    while ((c = getchar()) != '\n' && c != EOF);

    printf("Podaj druga liczbe: ");
    int s2 = scanf("%200s", num2);
    while ((c = getchar()) != '\n' && c != EOF);

    if(s1 != 1 || s2 != 1 || validate(num1) != 1 || validate(num2) != 1) {
        printf("Incorrect input\n");
        return 1;
    }

    if (add(num1, num2, res, sizeof(res)) == 0) printf("%s\n", res);
    else printf("Incorrect input\n");

    return 0;
}