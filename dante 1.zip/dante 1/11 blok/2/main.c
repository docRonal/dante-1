#include <stdio.h>

char *my_strpbrk(const char *where, const char *from){
    while (*where != '\0'){
        const char *temp = from;
        while (*temp != '\0'){
            if (*where != *temp) temp++;
            else return (char *) where;
        }
        where++;
    }
    return NULL;
}

int helper(const char *txt){
    int count = 0;
    const char *vec = "aeiyouAEIYOU";

    while (*txt != '\0')
    {
        char *what = my_strpbrk(txt, vec);
        if (what == NULL) break;

        count++;
        txt = what + 1;
    }
    return count;
}

int main()
{
    char text[1001];

    printf("Podaj text: ");
    scanf("%1000[^\n]",text);

    printf("\n%i\n", helper(text));

    return 0;
}