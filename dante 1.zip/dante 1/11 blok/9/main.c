#include <stdio.h>

int my_strlen(const char *str){
    int len = 0;
    while(*(len + str) != '\0'){
        len++;
    }
    return len;
}

int connect(const char* t1, const char* t2, const char* t3, char* t4, int size){
    if(t1 == NULL || t2 == NULL || t3 == NULL || size <= 0) return 1;

    if(t4 == NULL) return 1;

    int len = my_strlen(t1);
    int len1 = my_strlen(t2);
    int len2 = my_strlen(t3);

    if(len + len1 + len2 + 2 >= size) return 1;

    sprintf(t4,"%s %s %s",t1,t2,t3);

    return 0;
}

int main(){
    char txt1[1001];
    printf("Podaj tekst: ");
    scanf("%1000[^\n]",txt1);

    while (getchar() != '\n');

    char txt2[1001];
    printf("\nPodaj tekst: ");
    scanf("%1000[^\n]",txt2);

    while (getchar() != '\n');

    char txt3[1001];
    printf("\nPodaj tekst: ");
    scanf("%1000[^\n]",txt3);

    while (getchar() != '\n');
    char txt[3004];
    int size = 3004;

    if(connect(txt1,txt2,txt3,txt,size) != 0){
        printf("\nError!\n");
        return 1;
    }

    printf("\n%s\n",txt);

    return 0;
}