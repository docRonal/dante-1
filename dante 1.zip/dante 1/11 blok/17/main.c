#include <stdio.h>
#include <string.h>


int is_palindrom(const char *text) {
    if (!text) return -1;
    if(strlen(text) <= 1) return 0;

    const char *start = text;
    const char *end = text + strlen(text) - 1;

    while (start < end) {
        if (*start != *end) {
            return 0;
        }
        start++;
        end--;
    }

    return 1;
}

char* find_palindrom(char *text, int len) {
    if (!text || len <= 0) {
        return NULL;
    }

    char *start = text;
    char *end = text + strlen(text);

    while (start + len <= end) {
        char *sub_start = start;
        char *sub_end = start + len - 1;
        int is_palindrome = 1;

        while (sub_start < sub_end) {
            if (*sub_start != *sub_end) {
                is_palindrome = 0;
                break;
            }
            sub_start++;
            sub_end--;
        }

        if (is_palindrome) {
            *(start + len) = '\0';
            return start;
        }
        start++;
    }

    return NULL;
}

int create_palindrom(const char *text, char *out, int size) {
    if (!text || !out || size <= 0) {
        return 1;
    }

    int len = strlen(text);
    if (size < 2 * len + 1) {
        return 2;
    }

    const char *src = text;
    char *dest = out;

    while (*src) {
        *dest++ = *src++;
    }

    src = text + len - 1;
    while (src >= text) {
        *dest++ = *src--;
    }

    *dest = '\0';

    return 0;
}

int main() {
    char text[1001];
    printf("Podaj tekst:\n");
    if (!fgets(text, sizeof(text), stdin)) {
        printf("Incorrect input\n");
        return 1;
    }

    char *newline = text;
    while (*newline != '\0') {
        if (*newline == '\n') {
            *newline = '\0';
            break;
        }
        newline++;
    }
    int palindrome_check = is_palindrom(text);
    if (palindrome_check == 1) {
        printf("YES");
        return 0;
    } else if (palindrome_check == -1) {
        printf("Incorrect input\n");
        return 1;
    }

    printf("NO\n");

    printf("Co dalej? \n");
    if(strlen(text)==1000) {
        while(getchar() != '\n');
    }
    char choice;
    if (scanf("%c", &choice) != 1) {
        printf("Incorrect input\n");
        return 1;
    }

    if (choice == 'c' || choice == 'C') {
        char result[2002];
        int create_status = create_palindrom(text, result, sizeof(result));
        if (create_status == 0) {
            printf("%s", result);
        } else {
            printf("Incorrect input\n");
            return 1;
        }
    } else if (choice == 'f' || choice == 'F') {
        int len;
        printf("Podaj wymaganą długość: ");
        if (scanf("%d", &len) != 1) {
            printf("Incorrect input\n");
            return 1;
        }
        if(len <=0) {
            printf("Incorrect input data\n");
            return 2;
        }
        char *found = find_palindrom(text, len);
        if (found) {
            printf("%s", found);
        } else {
            printf("Couldn't find\n");
            return 0;
        }
    } else {
        printf("Incorrect input data\n");
        return 2;
    }

    return 0;
}