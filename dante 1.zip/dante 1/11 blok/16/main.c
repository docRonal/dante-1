#include<stdio.h>
#include<string.h>


int helper1(const char *mat, int i){
    const char *numbers = "1234567890";
    if (strspn(mat + i + 1, numbers) != 0 && *(mat + i) == '0') return 0;
    int n = strspn(mat + i, numbers);
    if (n == 0) return 0;
    i = i + n;
    if (*(mat + i) == '\0') return 1;
    return helper1(mat, i + 1);
}
int validate_expression(const char *mat){
    if (mat == NULL) return -1;
    const char *val = "+-*/1234567890";
    int size = (int)strlen(mat);
    if (size != (int) strspn(mat, val))return 0;
    return helper1(mat, 0);
}
void helper2(const char *mat, int i, float *res){
    if (*(mat + i) <= '9' && *(mat + i) >= '0'){
        *res = *res * 10;
        *res = *res + *(mat + i) - '0';
        helper2(mat, i + 1, res);
    }
}
int helper3(const char *mat, int i, float *res){
    if (*(mat + i) == '\0')return 1;
    char fun = *(mat + i);
    i++;
    float tmp = 0;
    helper2(mat, i, &tmp);
    const char *numbers = "1234567890";
    i = i + strspn(mat + i, numbers);

    switch (fun)
    {
        case '+':
            *res = *res + tmp;
            break;
        case '-':
            *res = *res - tmp;
            break;
        case '*':
            *res = *res * tmp;
            break;
        case '/':
            if (tmp == 0) return 0;
            *res = *res / tmp;
            break;
    }

    return helper3(mat, i, res);
}
int calculate(const char* mat, float *res){
    if (mat == NULL ||  res == NULL || !validate_expression(mat)) return 0;
    const char *numbers = "1234567890";
    *res = 0.0f;
    helper2(mat, 0, res);
    int iterator = strspn(mat, numbers);
    return helper3(mat, iterator, res);
}
void handle_input(char *inp, int size, int i){
    if (i >= size) *(inp + i) = '\0';
    else{
        char tmp = getchar();
        if (tmp == '\n') *(inp + i) = '\0';
        else{
            *(inp + i) = tmp;
            handle_input(inp, size, i + 1);
        }
    }
}

int main(){
    char mat[200 + 1];
    printf("Enter:");
    handle_input(mat, 200, 0);

    float res;
    if (calculate(mat, &res) == 0){
        printf("Incorrect input");
        return 1;
    }

    printf("%.2f\n", res);

    return 0;
}
