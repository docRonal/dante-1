#include <stdio.h>
#include <string.h>

int starts_with(const char* txt, const char* find) {
    if (txt == NULL || find == NULL) return -1;
    if (*find == '\0') return 1;
    if (*txt == '\0') return 0;
    return (*txt == *find) ? starts_with(txt + 1, find + 1) : 0;
}

int ends_with(const char* txt, const char* find) {
    if (txt == NULL || find == NULL)return -1;
    size_t txt_size = strlen(txt);
    size_t find_size = strlen(find);
    if (find_size > txt_size) return 0;
    const char* txt1 = txt + txt_size - find_size;
    return starts_with(txt1, find);
}

void remove_newline(char* str) {
    if (str == NULL || *str == '\0') return;
    if (*str == '\n') *str = '\0';
    else remove_newline(str + 1);
}

void exp_clear() {
    int c;
    if ((c = getchar()) != '\n' && c != EOF) exp_clear();
}

int expression(char* str, size_t size) {
    if (fgets(str, size, stdin) == NULL) return 0;
    if (strchr(str, '\n') == NULL) exp_clear();
    remove_newline(str);
    return 1;
}

int main() {
    char txt[101];
    char find[101];

    printf("Podaj tekst: ");
    fflush(stdout);
    if (!expression(txt, sizeof(txt)))
    {
        printf("Blad przy wczytywaniu tekstu\n");
        return -1;
    }

    printf("Podaj drugi tekst: ");
    fflush(stdout);
    if (!expression(find, sizeof(find)))
    {
        printf("Blad przy wczytywaniu drugiego tekstu\n");
        return -1;
    }

    printf("%d\n", starts_with(txt, find));
    printf("%d\n", ends_with(txt, find));

    return 0;
}
