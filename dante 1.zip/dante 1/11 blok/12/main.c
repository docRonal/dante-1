#include <stdio.h>

int message_compression(char* txt)
{
    if(txt == NULL) return -1;

    int count = 0;
    int ptr = 1;

    for (int i = 0; *(txt + i) != '\0'; i++){
        char check = *(txt + i);
        if ((check >= 'a' && check <= 'z') || (check >= 'A' && check <= 'Z')){
            if (ptr == 1)
            {
                if (check >= 'a' && check <= 'z') *(txt + i) = check - ('a' - 'A');

                ptr = 0;
            }
            else if (check >= 'A' && check <= 'Z') *(txt + i) = check + ('a' - 'A');
        }
        else{
            for (int j = i; *(txt + j) != '\0'; j++){
                *(txt + j) = *(txt + j + 1);
            }

            i--;
            count++;
            ptr = 1;
        }
    }

    return count;
}

int main()
{
    char txt[1001];
    printf("Podaj tekst: ");
    scanf("%1000[^\n]",txt);

    if (message_compression(txt) == -1){
        printf("\nNothingToShow\n");
        return 1;
    }

    int j = 0;
    for(int i = 0; *(txt + i) != '\0'; i++)
    {
        if((*(txt + i) >= 'a' && *(txt + i) <= 'z') || (*(txt + i) >= 'A' && *(txt + i) <= 'Z')) j = 1;
    }
    if(j != 1){
        printf("\nNothingToShow\n");
        return 0;
    }

    printf("\n%s\n",txt);

    return 0;
}