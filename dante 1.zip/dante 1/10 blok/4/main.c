#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int T[20] = {0};
    int *ptr;
    srand(time(NULL));

    for (ptr = T; ptr < T + 20; ptr++) {
        *ptr = rand();
    }

    for (ptr = T; ptr < T + 20; ++ptr) {
        printf("%d ", *ptr);
    }
    printf("\n");
    for (ptr = T; ptr < T + 20; ptr += 2) {
        printf("%d ", *ptr);
    }
    return 0;
}
