#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    float T[20] = {0};
    float *ptr;
    srand(time(NULL));

    for (ptr = T; ptr < T + 20; ptr++) {
        *ptr = (float)rand()/(float)(RAND_MAX);
    }

    for (ptr = T; ptr < T + 20; ++ptr) {
        printf("%.1f ", *ptr);
    }
    printf("\n");
    for (ptr = T; ptr < T + 20; ptr += 2) {
        printf("%.1f ", *ptr);
    }
    return 0;
}
