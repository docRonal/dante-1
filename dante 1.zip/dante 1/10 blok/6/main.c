#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    float T[100] = {0};
    float *ptr;
    int size;

    printf("Ile liczb chcesz wprowadzić?: ");
    if(scanf("%d", &size) != 1) {
        printf("Incorrect input");
        return 1;
    }
    if(size < 1 || size > 100) {
        printf("Incorrect input data");
        return 2;
    }

    printf("Podaj liczby: ");
    for (ptr = T; ptr < T + size; ptr++) {
        if(scanf("%f", ptr) != 1) {
            printf("Incorrect input\n");
            return 1;
        }
    }


    for (ptr = T+size; ptr > T; ptr--) {
        printf("%f ", *(ptr-1));
    }
    float sum = 0;
    for (ptr = T; ptr < T + size; ptr++) {
        sum += *(ptr);
    }
    printf("\nSuma: %.2f\n", sum);
    printf("Srednia: %.2f", sum/size);
    return 0;
}
