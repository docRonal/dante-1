#include <stdio.h>

int main() {
    int T[10] = {0};
    int *ptr;

    for (ptr = T; ptr < T + 10; ++ptr) {
        *ptr = ptr - T;
    }

    for (ptr = T; ptr < T + 10; ++ptr) {
        printf("%d ", *ptr);
    }

    return 0;
}
