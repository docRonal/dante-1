#include <stdio.h>
#include <math.h>

int dlugosc_liczby(long long liczba)
{
    int dlugosc = 0;
    if (liczba == 0)
    {
        return 1;
    }
    while (liczba > 0)
    {
        dlugosc++;
        liczba /= 10;
    }
    return dlugosc;
}

int main() {
    long long liczba1;
    long long liczba2;

    printf("Podaj liczbe: ");
    if (scanf("%lld", &liczba1) != 1)
    {
        printf("Incorrect input");
        return 1;
    }

    printf("Podaj liczbe: ");
    if (scanf("%lld", &liczba2) != 1)
    {
        printf("Incorrect input");
        return 1;
    }

    int dlugosc1 = dlugosc_liczby(liczba1);
    int dlugosc2 = dlugosc_liczby(liczba2);

    int max_dlugosc = dlugosc1 + dlugosc2 + 2;

    printf("%*lld\n", max_dlugosc, liczba1);
    printf("%*lld\n", max_dlugosc, liczba2);

    for (int i = 0; i < max_dlugosc; i++)
    {
        printf("-");
    }
    printf("\n");

    long long result = 0;
    int shift = 0;

    while (liczba2 > 0)
    {
        long long cyfrowy = liczba2 % 10;
        long long iloczyn_result = liczba1 * cyfrowy;
        printf("%*lld\n", max_dlugosc - shift, iloczyn_result);
        result += iloczyn_result * (long long)pow(10, shift);
        liczba2 /= 10;
        shift++;
    }
    if (result < 0)
    {
        max_dlugosc += 1;
    }

    for (int i = 0; i < max_dlugosc; i++)
    {
        printf("-");
    }
    printf("\n");

    printf("%*lld\n", max_dlugosc, result);

    return 0;
}
