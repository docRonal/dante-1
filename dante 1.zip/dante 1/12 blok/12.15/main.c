#include <stdio.h>
#include <string.h>
#define SIZE 100000

void transported(const char* exp, char* out_exp, int len) {
    if (*exp == '\0'){
        out_exp[0] = '\0';
        return;
    }

    int j = 0;

    if (*exp == '0'){
        out_exp[j++] = '1';
        out_exp[j++] = '0';
    }
    else if (*exp == '1'){
        out_exp[j++] = '0';
        out_exp[j++] = '1';
    }

    transported(exp + 1, out_exp + j, len - 1);
}

int count_00(const char* str, int index) {
    if (str[index] == '\0' || str[index + 1] == '\0') return 0;
    if (str[index] == '0' && str[index + 1] == '0') return 1 + count_00(str, index + 1);
    return count_00(str, index + 1);
}


void astep(char* str, int step, char* n) {
    if (step == 0)return;

    transported(str, n, strlen(str));
    strcpy(str, n);

    astep(str, step - 1, n);
}

int main() {
    int bstep;
    printf("Podaj liczbe: ");
    if (scanf("%d", &bstep) != 1){
        printf("Incorrect input");
        return 1;
    }
    if (bstep < 1 || bstep > 16){
        printf("Incorrect input data");
        return 2;
    }

    char buf[SIZE] = "1";
    char n[SIZE];

    astep(buf, bstep, n);

    printf("%s\n", buf);
    printf("%d\n", count_00(buf, 0));

    return 0;
}
