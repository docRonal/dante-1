#include <stdio.h>

int is_balanced(unsigned long long a) {
    unsigned long long liczba_parz_count = 0;
    unsigned long long liczba_nie_parz_count = 0;

    for (unsigned long long i = 1; i * i <= a; i++)
    {
        if (a % i == 0)
        {
            if (i % 2 == 0)
            {
                liczba_parz_count++;
            }
            else
            {
                liczba_nie_parz_count++;
            }
            unsigned long long para_liczb = a / i;
            if (para_liczb != i)
            {
                if (para_liczb % 2 == 0)
                {
                    liczba_parz_count++;
                }
                else
                {
                    liczba_nie_parz_count++;
                }
            }
        }
    }
    return liczba_parz_count == liczba_nie_parz_count;
}

int main() {
    unsigned long long liczba;

    printf("Podaj liczbe: ");
    if (scanf("%llu", &liczba) != 1)
    {
        printf("Incorrect input");
        return 1;
    }
    unsigned long long n = liczba + 1;
    while (!is_balanced(n))
    {
        n++;
    }
    // for (; !is_balanced(next); next++)
    // {
    //
    // }
    printf("%llu", n);
    return 0;
}
