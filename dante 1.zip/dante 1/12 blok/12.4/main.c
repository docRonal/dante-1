#include <stdio.h>
#include <ctype.h>

#define MAX_INPUT 1001

int main() {
    char arr_wyraz[MAX_INPUT];
    printf("Podaj tekst: ");
    if (fgets(arr_wyraz, sizeof(arr_wyraz), stdin) == NULL)
    {
        printf("NothingToShow");
        return 0;
    }
    char arr_wyjscie[MAX_INPUT];
    int wyjscie_index = 0;
    int wielka_litera = 1;
    for (int i = 0; arr_wyraz[i] != '\0'; i++)
    {
        if (isalpha(arr_wyraz[i]))
        {
            if (wielka_litera)
            {
                arr_wyjscie[wyjscie_index++] = toupper(arr_wyraz[i]);
                wielka_litera = 0;
            }
            else
            {
                arr_wyjscie[wyjscie_index++] = tolower(arr_wyraz[i]);
            }
        }
        else
        {
            wielka_litera = 1;
        }
    }

    arr_wyjscie[wyjscie_index] = '\0';

    if (wyjscie_index == 0)
    {
        printf("NothingToShow");
    }
    else
    {
        printf("%s", arr_wyjscie);
    }

    return 0;
}
