#include <stdio.h>

void cantor(int depth) {
    int size = 1;
    for (int d = 1; d < depth; ++d)
    {
        size *= 3;
    }

    for (int level = 0; level < depth; ++level)
    {
        for (int i = 0; i < size; ++i)
        {
            int in_em = 0;
            int k = 0;
            int curr_i = 3 * i;

            for (; k < level; curr_i %= size, curr_i *= 3, ++k)
            {
                in_em |= (curr_i / size == 1);
            }

            if (in_em)
            {
                putchar(' ');
            }
            else
            {
                putchar('_');
            }
        }
        putchar('\n');
    }
}

int main() {
    int depth;

    printf("Podaj glebokosc: ");
    if (scanf("%d", &depth) != 1)
    {
        printf("Incorrect input");
        return 1;
    }

    if (depth < 1 || depth > 6)
    {
        printf("Incorrect input data");
        return 2;
    }

    cantor(depth);

    return 0;
}
