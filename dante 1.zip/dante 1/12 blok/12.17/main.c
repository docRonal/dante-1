#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int can_react(char a, char b) {
    return abs(a - b) == ('a' - 'A');
}

int validate(const char* inp, int index) {
    if (inp[index] == '\0') return 1;

    if (!isalpha(inp[index])) return 0;

    return validate(inp, index + 1);
}

void reduce_polymer(const char* inp_arr, char* ex_arr, int ind_inp, int ind_ex) {
    if (inp_arr[ind_inp] == '\0'){
        ex_arr[ind_ex] = '\0';
        return;
    }
    if (ind_ex > 0 && can_react(ex_arr[ind_ex - 1], inp_arr[ind_inp])) reduce_polymer(inp_arr, ex_arr, ind_inp + 1, ind_ex - 1);

    else
    {
        ex_arr[ind_ex] = inp_arr[ind_inp];
        reduce_polymer(inp_arr, ex_arr, ind_inp + 1, ind_ex + 1);
    }
}

int main() {
    char arr[1001];

    printf("Podaj polimer: ");
    if (!fgets(arr, sizeof(arr), stdin)){
        printf("Incorrect input data");
        return 2;
    }

    arr[strcspn(arr, "\n")] = '\0';

    if (!validate(arr, 0))
    {
        printf("Incorrect input data");
        return 2;
    }

    char arr_exit[1001];

    reduce_polymer(arr, arr_exit, 0, 0);


    if (arr_exit[0] == '\0') printf("Nothing to show");

    else printf("%s", arr_exit);

    return 0;
}
