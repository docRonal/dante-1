#include <stdio.h>
#include <math.h>

int is_valid_input(int poczt, int koncowy) {
    return poczt <= koncowy && poczt > 0 && koncowy > 0;
}

double srednia_dzielnika(int liczba) {
    int suma = 0;
    int count = 0;
    for (int i = 1; i <= liczba / 2; i++)
    {
        if (liczba % i == 0)
        {
            suma += i;
            count++;
        }
    }
    return count == 0 ? 0 : (double)suma / count;
}

int is_this_number(int liczba) {
    double srednia = srednia_dzielnika(liczba);
    double pierwiastek = sqrt(liczba);
    return srednia <= pierwiastek;
}

int main() {
    int pocz_wyraz;
    int koncowy_wyraz;

    printf("Podaj poczatek: ");
    if (scanf("%d", &pocz_wyraz) != 1)
    {
        printf("Incorrect input");
        return 1;
    }

    printf("Podaj koniec: ");
    if (scanf("%d", &koncowy_wyraz) != 1)
    {
        printf("Incorrect input");
        return 1;
    }

    if (!is_valid_input(pocz_wyraz, koncowy_wyraz))
    {
        printf("Incorrect input data");
        return 2;
    }

    int significant_count = 0;
    for (int i = pocz_wyraz; i <= koncowy_wyraz; i++)
    {
        if (is_this_number(i))
        {
            significant_count++;
        }
    }

    printf("%d", significant_count);
    return 0;
}
