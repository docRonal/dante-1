#include <stdio.h>
#include <stdlib.h>

unsigned long long product_of_digits(unsigned long long n) {
    if (n == 0)
    {
        return 0;
    }
    if (n < 10)
    {
        return n;
    }
    return (n % 10) * product_of_digits(n / 10);
}

void factorize(int n, int* factors, int* factor_count, int divisor) {
    if (n == 1)
    {
        return;
    }
    if (divisor < 2)
    {
        *factor_count = 0;
        return;
    }
    if (n % divisor == 0)
    {
        factors[*factor_count] = divisor;
        (*factor_count)++;
        factorize(n / divisor, factors, factor_count, divisor);
    }
    else
    {
        factorize(n, factors, factor_count, divisor - 1);
    }
}

void copyLeft(int* factors, int* leftArr, int left, int n1, int index) {
    if (index < n1)
    {
        leftArr[index] = factors[left + index];
        copyLeft(factors, leftArr, left, n1, index + 1);
    }
}

void copyRight(int* factors, int* rightArr, int mid, int n2, int index) {
    if (index < n2)
    {
        rightArr[index] = factors[mid + 1 + index];
        copyRight(factors, rightArr, mid, n2, index + 1);
    }
}

void mergeRec(int* factors, int* leftArr, int* rightArr, int n1, int n2, int i, int j, int k) {
    if (i < n1 && j < n2)
    {
        if (leftArr[i] <= rightArr[j])
        {
            factors[k] = leftArr[i];
            mergeRec(factors, leftArr, rightArr, n1, n2, i + 1, j, k + 1);
        }
        else
        {
            factors[k] = rightArr[j];
            mergeRec(factors, leftArr, rightArr, n1, n2, i, j + 1, k + 1);
        }
    }
    else if (i < n1)
    {
        factors[k] = leftArr[i];
        mergeRec(factors, leftArr, rightArr, n1, n2, i + 1, j, k + 1);
    }
    else if (j < n2)
    {
        factors[k] = rightArr[j];
        mergeRec(factors, leftArr, rightArr, n1, n2, i, j + 1, k + 1);
    }
}

void mergeSort(int* factors, int left, int right) {
    if (left < right)
    {
        int mid = left + (right - left) / 2;
        mergeSort(factors, left, mid);
        mergeSort(factors, mid + 1, right);

        int n1 = mid - left + 1;
        int n2 = right - mid;

        int* leftArr = (int*)malloc(n1 * sizeof(int));
        int* rightArr = (int*)malloc(n2 * sizeof(int));

        copyLeft(factors, leftArr, left, n1, 0);
        copyRight(factors, rightArr, mid, n2, 0);

        mergeRec(factors, leftArr, rightArr, n1, n2, 0, 0, left);

        free(leftArr);
        free(rightArr);
    }
}

void printFactors(int* factors, int factor_count, int index) {
    if (index < factor_count) {
        printf("%d", factors[index]);
        printFactors(factors, factor_count, index + 1);
    }
}

int main() {
    long long n;

    printf("Podaj liczbe:\n");
    if (scanf("%lld", &n) != 1)
    {
        printf("Incorrect input");
        return 1;
    }

    if (n < 0 || n > 10000)
    {
        printf("Incorrect input data");
        return 2;
    }
    if (n == 0)
    {
        printf("10");
        return 0;
    }
    if (n == 1)
    {
        printf("1");
        return 0;
    }

    int factors[50];
    int factor_count = 0;

    factorize(n, factors, &factor_count, 9);

    if (factor_count == 0)
    {
        printf("NIE");
        return 0;
    }

    mergeSort(factors, 0, factor_count - 1);

    printFactors(factors, factor_count, 0);
    return 0;
}

