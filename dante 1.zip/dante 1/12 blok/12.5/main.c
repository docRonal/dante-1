// #include <stdio.h>
// #include <stdlib.h>
//
// #define MAX_SIZE 20
//
// void generate_fan(int n, int clockwise, char fan[MAX_SIZE][MAX_SIZE]) {
//     int size = 2 * n;
//
//     for (int i = 0; i < size; i++) {
//         for (int j = 0; j < size; j++) {
//             fan[i][j] = ' ';
//         }
//     }
//
//     for (int i = 0; i < n; i++) {
//         for (int j = 0; j < n; j++) {
//             fan[n - i - 1][n - j - 1] = 'X';
//             fan[n - i - 1][n + j] = 'X';
//             fan[n + i][n - j - 1] = 'X';
//             fan[n + i][n + j] = 'X';
//         }
//     }
//
//     int layer = n - 1;
//     for (int i = 0; i < n; i++) {
//         if (clockwise) {
//
//             for (int j = 0; j < n; j++) {
//                 fan[layer - i][j] = (j > i) ? ' ' : 'X';
//                 fan[size - layer + i - 1][size - j - 1] = (j > i) ? ' ' : 'X';
//             }
//         } else {
//             for (int j = 0; j < n; j++) {
//                 fan[j][layer - i] = (j > i) ? ' ' : 'X';
//                 fan[size - j - 1][size - layer + i - 1] = (j > i) ? ' ' : 'X';
//             }
//         }
//     }
// }
//
// void print_fan(char fan[MAX_SIZE][MAX_SIZE], int size) {
//     for (int i = 0; i < size; i++) {
//         for (int j = 0; j < size; j++) {
//             putchar(fan[i][j]);
//         }
//         putchar('\n');
//     }
// }
//
// int main() {
//     int r;
//     int inputs[11];
//     int count = 0;
//
//     while (count < 11) {
//         printf("Podaj liczbe: ");
//         scanf("%d", &r);
//         if (r == 0) break;
//         inputs[count++] = r;
//     }
//
//     for (int i = 0; i < count; i++) {
//         int n = abs(inputs[i]);
//         if (n > 10) {
//             printf("Out of memory.\n", n);
//             continue;
//         }
//
//         char fan[MAX_SIZE][MAX_SIZE];
//         generate_fan(n, inputs[i] < 0, fan);
//         print_fan(fan, 2 * n);
//
//         if (i < count - 1) {
//             putchar('\n');
//         }
//     }
//
//     return 0;
// }



#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 20

// Функция для генерации веера
void generate_fan(int n, int clockwise, char fan[MAX_SIZE][MAX_SIZE]) {
    // Инициализация массива пробелами
    int size = 2 * n;
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            fan[i][j] = ' ';
        }
    }

    // Генерация веера
    for (int i = 0; i < n; i++) {
        if (clockwise) {
            // По часовой стрелке
            for (int j = 0; j <= i; j++) {
                fan[i][n - j - 1] = 'X';  // Левая сторона
                fan[i][n + j] = 'X';      // Правая сторона
                fan[n + i][n - j - 1] = 'X'; // Нижняя левая
                fan[n + i][n + j] = 'X';     // Нижняя правая
            }
        } else {
            // Против часовой стрелки
            for (int j = 0; j <= i; j++) {
                fan[i][n - j - 1] = 'X';    // Левая сторона
                fan[i][n + j] = 'X';        // Правая сторона
                fan[n + i][n - j - 1] = 'X'; // Нижняя левая
                fan[n + i][n + j] = 'X';     // Нижняя правая
            }
        }
    }
}

// Функция для вывода веера
void print_fan(char fan[MAX_SIZE][MAX_SIZE], int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            putchar(fan[i][j]);
        }
        putchar('\n');
    }
}

int main() {
    int r;
    int inputs[11];
    int count = 0;

    // Ввод данных
    while (count < 11) {
        printf("Podaj liczbe: ");
        scanf("%d", &r);
        if (r == 0) break;
        inputs[count++] = r;
    }

    // Генерация и вывод вееров
    for (int i = 0; i < count; i++) {
        int n = abs(inputs[i]);
        if (n > 10) {
            printf("Out of memory.\n");
            continue;
        }

        char fan[MAX_SIZE][MAX_SIZE];
        generate_fan(n, inputs[i] < 0, fan);
        print_fan(fan, 2 * n);

        if (i < count - 1) {
            putchar('\n');
        }
    }

    return 0;
}
