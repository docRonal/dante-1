#include <stdio.h>

int dlugosc_liczby(int liczba) {
    int dlugosc = 0;
    if (liczba == 0)
    {
        return 1;
    }
    while (liczba > 0)
    {
        dlugosc++;
        liczba /= 10;
    }
    return dlugosc;
}

int main() {
    int n;

    printf("Podaj N: ");
    if (scanf("%d", &n) != 1)
    {
        printf("Incorrect input");
        return 1;
    }

    if (n < 0 || n > 100000)
    {
        printf("Incorrect input");
        return 1;
    }

    int found = 0;

    for (int x = 10; x < n; x++)
    {
        int y = n - x;
        if (dlugosc_liczby(y) == dlugosc_liczby(x) - 1)
        {
            printf("%d + %d = %d\n", x, y, n);
            found = 1;
        }
    }

    if (!found)
    {
        printf("Nothing to show");
    }

    return 0;
}
