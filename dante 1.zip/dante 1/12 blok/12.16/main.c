#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define DZIELNIK 10

int is_prime(unsigned long long num) {
    if (num < 2) return 0;

    for (unsigned long long i = 2; i * i <= num; i++){
        if (num % i == 0) return 0;
    }
    return 1;
}

unsigned long long find_largest_prime_number(unsigned long long num) {
    unsigned long long max_prime = 0;
    unsigned long long num_copy = num;

    int digit = 0;
    while (num_copy > 0){
        digit++;
        num_copy /= DZIELNIK;
    }

    for (int len = 1; len <= digit; len++){
        for (int start = 0; start <= digit - len; start++){
            unsigned long long fragm = 0;

            unsigned long long temp_buff_num = num;
            for (int i = 0; i < digit - start - len; i++){
                temp_buff_num /= DZIELNIK;
            }

            fragm = temp_buff_num % (unsigned long long)(pow(DZIELNIK, len));

            if (is_prime(fragm) && fragm > max_prime) max_prime = fragm;

        }
    }
    return max_prime;
}

int main() {
    unsigned long long exp;
    printf("Podaj liczbe: ");
    if (scanf("%llu", &exp) != 1){
        printf("Incorrect input");
        return 1;
    }

    unsigned long long max = find_largest_prime_number(exp);

    printf("%llu", max);
    return 0;
}
