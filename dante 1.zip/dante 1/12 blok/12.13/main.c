#include <stdio.h>
#include <math.h>

unsigned long count_zeros(unsigned long N) {
    unsigned long czynnik = 1;
    unsigned long count = 0;

    while (czynnik <= N)
    {
        unsigned long naj_nisz_liczba = N % czynnik;
        unsigned long curr_cyfr = (N / czynnik) % 10;
        unsigned long naj_wysza_liczba = N / (czynnik * 10);

        if (curr_cyfr == 0)
        {
            count += naj_wysza_liczba * czynnik;
            count += naj_nisz_liczba + 1;
            if (naj_nisz_liczba > 0)
            {
                count += naj_nisz_liczba + 1;
            }
        }

        if (naj_wysza_liczba > 0 && curr_cyfr == 0)
        {
            count -= naj_nisz_liczba + 1;
        }
        else
        {
            count += naj_wysza_liczba * czynnik;
        }

        czynnik *= 10;
    }

    return count;
}

void generate_histogram(unsigned long N, int hist[]) {
    for (int i = 0; i < 10; i++)
    {
        hist[i] = 0;
    }

    unsigned long czynnik = 1;

    while (czynnik <= N)
    {
        unsigned long naj_nisz_liczba = N % czynnik;
        unsigned long curr_cyfr = (N / czynnik) % 10;
        unsigned long naj_wysza_liczba = N / (czynnik * 10);

        for (unsigned long i = 0; i < 10; i++)
        {
            if (i < curr_cyfr)
            {
                hist[i] += (naj_wysza_liczba + 1) * czynnik;
            }
            else if (i == curr_cyfr)
            {
                hist[i] += naj_wysza_liczba * czynnik + naj_nisz_liczba + 1;
            }
            else
            {
                hist[i] += naj_wysza_liczba * czynnik;
            }
        }

        if (czynnik >= 1)
        {
            hist[0] -= czynnik;
        }

        czynnik *= 10;
    }
}

int main() {
    unsigned long N;

    printf("Podaj liczbe: ");
    if (scanf("%lu", &N) != 1)
    {
        printf("Incorrect input");
        return 1;
    }

    if (N < 1 || N > pow(10, 9))
    {
        printf("Incorrect input");
        return 1;
    }

    int hist[10] = {0};

    generate_histogram(N, hist);

    for (int i = 0; i < 10; i++)
    {
        printf("%d\n", hist[i]);
    }

    return 0;
}

