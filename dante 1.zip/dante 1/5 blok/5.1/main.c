#include <stdio.h>

#define SIZE 26

int main(void)
{
    int arr[SIZE];
    for (int i = 0; i < SIZE; i++)
    {
        arr[i] = 65 + i;
    }
    for (int i = 0; i < SIZE; i++)
    {
        printf("%d %c %c\n", arr[i], arr[i], arr[i] + 32);
    }
    return 0;
}
