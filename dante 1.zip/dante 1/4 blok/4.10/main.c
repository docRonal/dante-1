#include <stdio.h>

#define SIZE 100

int main(void)
{
    int arr[SIZE];
    int liczba;
    int count = 0;
    float suma = 0;
    printf("Podaj liczbę ciągu\n");
    for (int i = 0; i < SIZE; i++)
    {
        if (scanf("%d", &liczba) != 1)
        {
            printf("Incorrect input\n");
            return 1;
        }
        if (liczba == -1)
        {
            break;
        }
        if (count >= 100)
        {
            printf("Incorrect input\n");
            return 1;
        }
        arr[count] = liczba;
        count++;
        suma += liczba;
    }

    int max = arr[0];
    int min = arr[0];

    int index_count_max = 0;
    int index_count_min = 0;
    int index_max[SIZE];
    int index_min[SIZE];
    for (int i = 0; i < count; i++)
    {
        if (arr[i] < min)
        {
            min = arr[i];
            index_count_min = 0;
            index_min[index_count_min++] = i;
        }
        else if (arr[i] == min)
        {
            index_min[index_count_min++] = i;
        }
        if (arr[i] > max)
        {
            max = arr[i];
            index_count_max = 0;
            index_max[index_count_max++] = i;
        }
        else if (arr[i] == max)
        {
            index_max[index_count_max++] = i;
        }
    }
    float srednia = 0;
    srednia = suma / (float)count;

    printf("%d\n", count);
    printf("%d\n%d\n", min, max);
    printf("%f\n", srednia);
    printf("%0.0f\n", suma);
    for (int i = 0; i < index_count_min; i++) {
        printf("%d ", index_min[i]);
    }
    printf("\n");
    for (int i = 0; i < index_count_max; i++) {
        printf("%d ", index_max[i]);
    }
    return 0;
}