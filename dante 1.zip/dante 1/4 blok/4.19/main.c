#include <stdio.h>

#define MAX_SIZE 100

int main() {
    int arr[MAX_SIZE];
    int n = 0;
    int liczba;

    printf("podaj liczby: ");

    while (n < MAX_SIZE)
        {
        if (scanf("%d", &liczba) != 1)
            {
            printf("Incorrect input\n");
            return 1;
        }

        if (liczba == 0)
        {
            break;
        }
        arr[n++] = liczba;
    }

    if (n < 1)
    {
        printf("not enough data available\n");
        return 2;
    }

    int count[MAX_SIZE] = {0};

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (arr[i] == arr[j])
            {
                count[i]++;
            }
        }
    }

    int found_duplicates = 0;

    for (int i = 0; i < n; i++)
    {
        if (count[i] > 1)
        {
            int already_printed = 0;
            for (int j = 0; j < i; j++)
            {
                if (arr[i] == arr[j])
                {
                    already_printed = 1;
                    break;
                }
            }
            if (!already_printed)
            {
                printf("%d ", arr[i]);
                found_duplicates = 1;
            }
        }
    }

    if (!found_duplicates)
    {
        printf("Nothing to show");
    }

    return 0;
}