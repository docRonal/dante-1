#include <stdio.h>

int main(void)
{
    printf("podaj liczby:");
    int liczba;
    int arr[11] = {0};
    while (1) {
        int sprawdzenie = scanf("%d", &liczba);
        if (sprawdzenie != 1)
        {
            printf("Incorrect input");
            return 1;
        }
        if (liczba == -1)
        {
            break;
        }
        if (liczba >= 0 && liczba <= 10)
        {
            arr[liczba]++;
        }
    }
    for (int i = 0; i <= 10; i++)
    {
        printf("%d - %d\n", i, arr[i]);
    }
    return 0;
}
