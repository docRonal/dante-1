#include <stdio.h>

int main(void)
{
    printf("podaj liczby:");
    int liczba;
    int arr[100];
    int count = 0;
    for (int i = 0; i < 100; i++)
    {
        if (scanf("%d", &liczba) != 1)
        {
            printf("Incorrect input");
            return 1;
        }
        if (liczba == 0)
        {
            break;
        }
        arr[count] = liczba;
        count++;
    }
    if (count == 0)
    {
        printf("not enough data available");
        return 2;
    }
    for (int i = 0; i < count; i++)
    {
        int duplicate = 0;
        for (int j = 0; j < i; j++)
        {
            if (arr[i] == arr[j])
            {
                duplicate = 1;
                break;
            }
        }

        if (!duplicate)
        {
            printf("%d ", arr[i]);
        }
    }
    return 0;
}
