// #include <stdio.h>
//
// #define SIZE 100
//
// int main(void)
// {
//     printf("podaj liczby:\n");
//     int arr1[SIZE], arr2[SIZE];
//     int lenght1 = 0, lenght2 = 0;
//     int liczba;
//
//     for (int i = 0; i < SIZE; i++)
//     {
//         if (scanf("%d", &liczba) != 1)
//         {
//             printf("Incorrect input ");
//             return 1;
//         }
//         if (lenght1 < 0 || lenght1 >= 100)
//         {
//             printf("not enough data available ");
//             return 2;
//         }
//         if (liczba == 0)
//         {
//             break;
//         }
//         arr1[lenght1++] = liczba;
//     }
//
//     printf("podaj liczby:\n");
//
//     for (int i = 0; i < SIZE; i++)
//     {
//         if (scanf("%d", &liczba) != 1)
//         {
//             printf("Incorrect input ");
//             return 1;
//         }
//         if (lenght2 < 0 || lenght2 >= 100)
//         {
//             printf("not enough data available ");
//             return 2;
//         }
//         if (liczba == 0)
//         {
//             break;
//         }
//         arr2[lenght2++] = liczba;
//     }
//
//     int found_any = 0;
//
//     for (int i = 0; i < SIZE; i++)
//     {
//         int num = arr2[i];
//
//         int found = 0;
//         for (int j = 0; j < i; j++)
//         {
//             if (arr2[j] == num)
//             {
//                 found = 1;
//                 break;
//             }
//         }
//
//         if (found) {
//             continue;
//         }
//
//         int count = 0;
//         for (int j = 0; j < SIZE; j++)
//         {
//             if (arr2[j] == num)
//             {
//                 count++;
//             }
//         }
//
//         if (count >= 2)
//         {
//             int is_in_first = 0;
//             for (int j = 0; j < SIZE; j++)
//             {
//                 if (arr1[j] == num)
//                 {
//                     is_in_first = 1;
//                     break;
//                 }
//             }
//
//             if (!is_in_first)
//             {
//                 if (!found_any) {
//                     found_any = 1;
//                 }
//                 printf("%d ", num);
//             }
//         }
//     }
//     if (!found_any)
//     {
//         printf("Nothing to show");
//     }
//     return 0;
// }
// #include <stdio.h>
//
// #define SIZE 100
//
// int main(void)
// {
//     int arr1[SIZE], arr2[SIZE];
//     int length1 = 0, length2 = 0;
//     int liczba;
//
//     printf("podaj liczby do pierwszego ciagu:\n");
//     while (length1 < SIZE)
//     {
//         if (scanf("%d", &liczba) != 1) {
//             printf("Incorrect input\n");
//             return 1;
//         }
//         if (liczba == 0) break;
//         arr1[length1++] = liczba;
//     }
//
//     if (length1 < 0 || length1 <= 100) {
//         printf("not enough data available\n");
//         return 2;
//     }
//
//     while (length2 < SIZE)
//     {
//         if (scanf("%d", &liczba) != 1) {
//             printf("Incorrect input\n");
//             return 1;
//         }
//         if (liczba == 0) break;
//         arr2[length2++] = liczba;
//     }
//
//     if (length2 < 0 || length2 <= 100) {
//         printf("not enough data available\n");
//         return 2;
//     }
//
//     int found_any = 0;
//
//     for (int i = 0; i < length2; i++)
//     {
//         int num = arr2[i];
//         int count = 0;
//
//         for (int j = 0; j < length2; j++) {
//             if (arr2[j] == num) {
//                 count++;
//             }
//         }
//
//         if (count >= 2)
//         {
//             int is_in_first = 0;
//             for (int j = 0; j < length1; j++) {
//                 if (arr1[j] == num) {
//                     is_in_first = 1;
//                     break;
//                 }
//             }
//
//
//             if (!is_in_first)
//             {
//                 if (!found_any) {
//                     found_any = 1;
//                 }
//                 printf("%d ", num);
//             }
//         }
//     }
//
//     if (!found_any) {
//         printf("Nothing to show\n");
//     }
//
//     return 0;
// }
#include <stdio.h>

#define SIZE 100

int main(void) {
    int arr1[SIZE], arr2[SIZE];
    int length1 = 0, length2 = 0;
    int liczba;

    // Wczytanie pierwszego ciągu
    printf("Podaj liczby do pierwszego ciagu (0 kończy wprowadzanie):\n");
    while (length1 < SIZE) {
        if (scanf("%d", &liczba) != 1) {
            printf("Incorrect input\n");
            return 1;
        }
        if (liczba == 0) break;
        arr1[length1++] = liczba;
    }

    // Sprawdzenie, czy pierwszy ciąg ma co najmniej jedną liczbę
    if (length1 == 0) {
        printf("not enough data available\n");
        return 2;
    }

    // Wczytanie drugiego ciągu
    printf("Podaj liczby do drugiego ciagu (0 kończy wprowadzanie):\n");
    while (length2 < SIZE) {
        if (scanf("%d", &liczba) != 1) {
            printf("Incorrect input\n");
            return 1;
        }
        if (liczba == 0) break;
        arr2[length2++] = liczba;
    }

    // Sprawdzenie, czy drugi ciąg ma co najmniej jedną liczbę
    if (length2 == 0) {
        printf("not enough data available\n");
        return 2;
    }

    // Flaga do sprawdzenia, czy znaleziono jakieś elementy do wyświetlenia
    int found_any = 0;

    // Sprawdzanie elementów z drugiego ciągu
    for (int i = 0; i < length2; i++) {
        int num = arr2[i];
        int count = 0;

        // Liczymy, ile razy num występuje w drugim ciągu
        for (int j = 0; j < length2; j++) {
            if (arr2[j] == num) {
                count++;
            }
        }

        // Jeśli pojawił się co najmniej dwa razy
        if (count >= 2) {
            // Sprawdzamy, czy num występuje w pierwszym ciągu
            int is_in_first = 0;
            for (int j = 0; j < length1; j++) {
                if (arr1[j] == num) {
                    is_in_first = 1;
                    break;
                }
            }

            // Jeśli nie występuje w pierwszym ciągu, wypisujemy num
            if (!is_in_first) {
                if (!found_any) {
                    found_any = 1;
                }
                printf("%d ", num);
            }
        }
    }

    // Jeśli nie znaleziono żadnych wyników
    if (!found_any) {
        printf("Nothing to show\n");
    }

    return 0;
}
