#include <stdio.h>

int main(void)
{
    printf("podaj liczby: \n");

    int arr[10];
    int liczby;

    for (int i = 0; i < 10; i++)
    {
        if (scanf("%d",&liczby) != 1)
        {
            printf("Incorrect input");
            return 1;
        }
        arr[i] = liczby;
    }

    int count = 0;
    int even[4];

    for (int i = 0; i < 10; i++)
    {
        if (arr[i] % 2 == 0)
        {
            even[count] = arr[i];
            count++;
        }
    }

    int arr2[10];
    int evenCount = 0, oddCount = 0;

    if (count != 4)
    {
        printf("Incorrect input data ");
        return 2;
    }
    else
    {
        for (int i = 0; i < 10; i++)
        {
            if (i == 0 || i == 3 || i == 6 || i == 9)
            {
                arr2[i] = even[evenCount++];
            }
        }
        for (int i = 0; i < 10; i++)
        {
            if (i != 0 && i != 3 && i != 6 && i != 9)
            {
                for (int j = 0; j < 4; j++)
                {
                    if (arr[oddCount] % 2 == 0)
                    {
                        oddCount++;
                    }
                }
                arr2[i] = arr[oddCount++];
            }
        }
    }

    for (int i = 0; i < 10; i++)
    {
        printf("%d ",arr2[i]);
    }
    return 0;
}