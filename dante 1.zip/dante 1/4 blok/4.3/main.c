#include <stdio.h>

int main(void)
{
    int arr[11];
    for (int i = 0; i < 11; i++)
    {
        arr[i] = i;
    }
    for (int i = 0; i < 11; i++)
    {
        printf("%d ", arr[i]);
        if (i == 10)
        {
            printf("\n");
        }
    }
    return 0;
}
