#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 1000

int main() {
    int numbers[MAX_SIZE];
    int count = 0;

    // Wczytywanie liczb
    printf("Podaj liczby: ");
    while (1) {
        int input;
        if (scanf("%d", &input) != 1) {
            printf("Incorrect input\n");
            return 1;
        }

        if (input == 0) {
            break;
        }

        if (count >= MAX_SIZE) {
            break;
        }

        numbers[count] = input;
        count++;
    }

    // Jeśli nie ma wystarczającej liczby danych
    if (count < 2) {
        printf("not enough data available\n");
        return 2;
    }

    // Szukanie najdłuższych podciągów rosnących
    int longest_len = 0;
    int subsequences_count = 0;

    // Tablica do przechowywania długości rosnących podciągów
    int lengths[MAX_SIZE];
    int prev[MAX_SIZE];  // Array to keep track of the previous index for each element

    for (int i = 0; i < count; i++) {
        lengths[i] = 1; // Każdy element może samodzielnie tworzyć podciąg
        prev[i] = -1;   // Brak poprzednika
    }

    // Wyliczanie długości najdłuższych rosnących podciągów
    for (int i = 1; i < count; i++) {
        for (int j = 0; j < i; j++) {
            if (numbers[i] > numbers[j] && lengths[i] < lengths[j] + 1) {
                lengths[i] = lengths[j] + 1;
                prev[i] = j;
            }
        }
    }

    // Znalezienie najdłuższej długości podciągu
    longest_len = lengths[0];
    for (int i = 1; i < count; i++) {
        if (lengths[i] > longest_len) {
            longest_len = lengths[i];
        }
    }

    // Policz ile jest takich podciągów
    for (int i = 0; i < count; i++) {
        if (lengths[i] == longest_len) {
            subsequences_count++;
        }
    }

    // Wypisanie wyników
    printf("%d\n", longest_len);
    printf("%d\n", subsequences_count);

    // Wypisanie wszystkich najdłuższych podciągów rosnących
    // for (int i = 0; i < count; i++) {
    //     if (lengths[i] == longest_len) {
    //         // Odnajdź początek najdłuższego podciągu
    //         int index = i;
    //         int sequence[MAX_SIZE];
    //         int seq_len = 0;
    //
    //         // Rekonstrukcja podciągu
    //         while (index != -1) {
    //             sequence[seq_len++] = numbers[index];
    //             index = prev[index];
    //         }

            // Wypisanie podciągu w odwrotnej kolejności
        //     printf("%d ", i - seq_len + 1);
        //     for (int j = seq_len - 1; j >= 0; j--) {
        //         printf("%d ", sequence[j]);
        //     }
        //     printf("\n");
    //     }
    // }

    return 0;
}
// #include <stdio.h>
// #include <stdlib.h>
//
// #define MAX_SIZE 1000
//
// int main() {
//     int numbers[MAX_SIZE];
//     int count = 0;
//
//     // Wczytywanie liczb
//     printf("Podaj liczby: ");
//     while (1) {
//         int input;
//         if (scanf("%d", &input) != 1) {
//             printf("Incorrect input\n");
//             return 1;
//         }
//
//         if (input == 0) {
//             break;
//         }
//
//         if (count >= MAX_SIZE) {
//             break;
//         }
//
//         numbers[count] = input;
//         count++;
//     }
//
//     // Jeśli nie ma wystarczającej liczby danych
//     if (count < 2) {
//         printf("not enough data available\n");
//         return 2;
//     }
//
//     // Szukanie najdłuższych podciągów rosnących
//     int longest_len = 0;
//     int subsequences_count = 0;
//
//     // Tablica do przechowywania długości rosnących podciągów
//     int lengths[MAX_SIZE];
//     for (int i = 0; i < count; i++) {
//         lengths[i] = 1; // Każdy element może samodzielnie tworzyć podciąg
//     }
//
//     // Wyliczanie długości najdłuższych rosnących podciągów
//     for (int i = 1; i < count; i++) {
//         for (int j = 0; j < i; j++) {
//             if (numbers[i] > numbers[j] && lengths[i] < lengths[j] + 1) {
//                 lengths[i] = lengths[j] + 1;
//             }
//         }
//     }
//
//     // Znalezienie najdłuższej długości podciągu
//     longest_len = lengths[0];
//     for (int i = 1; i < count; i++) {
//         if (lengths[i] > longest_len) {
//             longest_len = lengths[i];
//         }
//     }
//
//     // Policz ile jest takich podciągów
//     for (int i = 0; i < count; i++) {
//         if (lengths[i] == longest_len) {
//             subsequences_count++;
//         }
//     }
//
//     // Wypisanie wyników
//     printf("%d\n", longest_len);
//     printf("%d\n", subsequences_count);
//
//     // Wypisanie wszystkich najdłuższych podciągów rosnących
//     for (int i = 0; i < count; i++) {
//         if (lengths[i] == longest_len) {
//             // Wypisujemy podciąg zaczynający się od i
//             int subseq_start = i;
//             printf("%d ", subseq_start);
//
//             // Wypisywanie samego podciągu
//             int subseq_len = longest_len;
//             int j = subseq_start;
//             printf("%d", numbers[j]);
//             subseq_len--;
//
//             // Wypisujemy kolejne elementy podciągu
//             for (j = subseq_start + 1; subseq_len > 1 && j < count; j++) {
//                 if (numbers[j] > numbers[j-1]) {
//                     printf(" %d", numbers[j]);
//                     subseq_len--;
//                 }
//             }
//             printf("\n");
//         }
//     }
//
//     return 0;
// }

