#include <stdio.h>

#define SIZE 10

int main(void)
{
    float arr[SIZE];
    printf("Napisz elementy po dwa za raz: ");
    for (int i = 0; i < SIZE; i += 2)
    {
        if (scanf("%f %f", &arr[i], &arr[i+1]) != 2)
        {
            printf("Input data type error");
            return 1;
        }
    }

    for (int i = 0; i < SIZE; i++)
    {
        printf("numer indexu: %d - %f \n" ,i, arr[i]);
    }
    return 0;
}
