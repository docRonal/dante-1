#include <stdio.h>
#include <math.h>

#define SIZE 10

int main(void)
{
    int arr[SIZE];
    printf("Napisz elementy po dwa za raz: \n");
    for (int i = 0; i < SIZE; i += 2)
    {
        if (scanf("%d %d", &arr[i], &arr[i+1]) != 2)
        {
            printf("Input data type error");
            return 1;
        }
    }

    for (int i = 0; i < SIZE; i++)
    {
        if (arr[i] <= 1)
        {
            printf("%d other\n", arr[i]);
        }
        else
        {
            int p = 0;
            for (int j = 2; j <= sqrt(arr[i]); j++)
            {
                if (arr[i] % j == 0)
                {
                    p = 1;
                    break;
                }
            }
            if (p == 0)
            {
                printf("%d prime\n", arr[i]);
            }
            else
            {
                printf("%d composite \n", arr[i]);
            }
        }
    }
    return 0;
}
