#include <stdio.h>

#define SIZE 10

int main(void)
{
    int arr[SIZE];
    printf("Napisz elementy po dwa za raz: \n");
    for (int i = 0; i < SIZE; i += 2)
    {
        if (scanf("%d %d", &arr[i], &arr[i+1]) != 2)
        {
            printf("Input data type error");
            return 1;
        }
    }

    for (int i = 0; i < SIZE; i++)
    {
        if (arr[i] % 2 == 0)
        {
            printf("%d even\n", arr[i]);
        }
        else
        {
            printf("%d odd\n", arr[i]);
        }
    }
    return 0;
}