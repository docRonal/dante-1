#include <stdio.h>

#define SIZE 1000

int main() {
    int arr[SIZE];
    int count = 0;

    printf("Podaj liczby:\n");
    for (int i = 0; i < SIZE; i++)
    {
        int liczba;
        if (scanf("%d", &liczba) != 1)
        {
            printf("Incorrect input");
            return 1;
        }
        if (liczba == 0)
        {
            break;
        }
        arr[count++] = liczba;
    }

    if (count == 0)
        {
        printf("Brak danych\n");
        return 0;
        }

    int suma = 0;

    for (int i = 0; i < count; i++)
    {
        suma = suma + arr[i];
    }

    float srednia = 0;
    srednia = (double)suma / count;
    printf("%.2f\n", srednia);

    int wieksza = 0;
    int mniejsza = 0;

    for (int i = 0; i < count; i++)
    {
        if (arr[i] > srednia)
        {
            wieksza += arr[i];
        }
        else if (arr[i] < srednia)
        {
            mniejsza += arr[i];
        }
    }
    printf("%d\n", wieksza);
    printf("%d\n", mniejsza);
    return 0;
}
