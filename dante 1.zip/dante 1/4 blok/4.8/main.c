#include <stdio.h>

int main(void)
{
    printf("podaj liczby :\n");
    int arr[10];
    for (int i = 0; i < 10; i+=2)
    {
        if (scanf("%d %d", &arr[i], &arr[i + 1]) != 2)
        {
            printf("Input data type error");
            return 1;
        }
    }
    int min = arr[0];
    int max = arr[0];
    float srednia = 0;
    int suma = 0;
    for (int i = 0; i < 10; i++)
    {
        suma += arr[i];
        if (arr[i] > max)
        {
            max = arr[i];
        }
        if (arr[i] < min)
        {
            min = arr[i];
        }
    }
    srednia = (float)suma / 10;
    printf("srednia = %.4f\n", srednia);
    printf("max = %d\nmin = %d\n", max, min);

    return 0;
}
