#include <stdio.h>

#define SIZE 100

int main(void)
{
    int arr[SIZE];
    int liczba;
    int count = 0;
    float suma = 0;
    printf("Podaj liczbę ciągu\n");
    for (int i = 0; i < SIZE; i++)
    {
        if (scanf("%d", &liczba) != 1)
        {
            printf("Incorrect input\n");
            return 1;
        }
        if (liczba == -1)
        {
            break;
        }
        if (count >= 100)
        {
            printf("Incorrect input\n");
            return 1;
        }
        arr[count] = liczba;
        count++;
        suma += liczba;
    }

    int max = arr[0];
    int min = arr[0];

    for (int i = 0; i < count; i++)
    {
        if (arr[i] < min)
        {
            min = arr[i];
        }
        if (arr[i] > max)
        {
            max = arr[i];
        }
    }

    float srednia = 0;
    srednia = suma / (float)count;

    printf("%d\n", count);
    printf("%d\n%d\n", min, max);
    printf("%f\n", srednia);
    printf("%0.0f\n", suma);
    return 0;
}