#include <math.h>
#include <stdio.h>

int main(void)
{
    printf("podaj liczby:");
    int liczba;
    int arr[100];
    int count = 0;
    for (int i = 0; i < 100; i++)
    {
        if (scanf("%d", &liczba) != 1)
        {
            printf("Incorrect input");
            return 1;
        }
        if (liczba == 0)
        {
            break;
        }
        arr[count] = liczba;
        count++;
    }
    if (count == 0)
    {
        printf("not enough data available");
        return 2;
    }
    if (count < 2)
    {
        printf("Nothing to show");
    }
    for (int i = count - 1; i >= 2; i--)
    {
        int liczba_pierwsza = 0;
        for (int j = 2; j <= sqrt(i); j++)
        {
            if (i % j == 0)
            {
                liczba_pierwsza = 1;
                break;
            }
        }
        if (liczba_pierwsza != 1)
        {
            printf("%d ", arr[i]);
        }
    }
    return 0;
}
