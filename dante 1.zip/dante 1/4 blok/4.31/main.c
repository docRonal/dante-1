#include <stdio.h>

#define MAX_SIZE 100

int main() {
    int seq1[MAX_SIZE], seq2[MAX_SIZE];
    int len1 = 0, len2 = 0;

    printf("podaj liczby:");
    while (1) {
        int num = 0;
        if (scanf("%d", &num) != 1)
        {
            printf("Incorrect input");
            return 1;
        }
        if (num == 0)
        {
            break;
        }
        if (len1 < MAX_SIZE)
        {
            seq1[len1] = num;
            len1++;
        }
        else
        {
            break;
        }
    }

    if (len1 < 2)
    {
        printf("not enough data available");
        return 2;
    }

    printf("podaj liczby:");
    while (1)
    {
        int num = 0;
        if (scanf("%d", &num) != 1)
        {
            printf("Incorrect input");
            return 1;
        }

        if (num == 0)
        {
            break;
        }

        if (len2 < MAX_SIZE)
        {
            seq2[len2] = num;
            len2++;
        }
        else
        {
            break;
        }
    }

    if (len2 == 0)
    {
        printf("not enough data available");
        return 2;
    }

    for (int i = 0; i < len1 - 1; i++)
    {
        int a = seq1[i];
        int b = seq1[i + 1];

        int lower, upper;
        if (a < b)
        {
            lower = a;
            upper = b;
        }
        else
        {
            lower = b;
            upper = a;
        }

        int count_in_range = 0;
        for (int j = 0; j < len2; j++)
        {
            if (seq2[j] > lower && seq2[j] < upper)
            {
                count_in_range++;
            }
        }

        printf("%d ", count_in_range);
    }
    printf("\n");

    return 0;
    /////////////////////////////////// grgrgrg
}

///////////////////////////////////////////g grgrgrgrg